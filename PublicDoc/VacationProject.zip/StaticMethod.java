public class StaticMethod {

		public static int totalnum = 13;
	
}